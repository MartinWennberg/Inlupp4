package Introduktion;

import java.awt.*;
import java.util.Random;

public class Cirkel {
    Color färg;

    Point position;

    Cirkel(Point position){
        Random random = new Random();
        int värde = random.nextInt(256);
        färg = new Color(värde, värde, värde);
        this.position = position;
    }


    void flytta(int antalPixlar_x){
        position.x += antalPixlar_x;
    }
}
