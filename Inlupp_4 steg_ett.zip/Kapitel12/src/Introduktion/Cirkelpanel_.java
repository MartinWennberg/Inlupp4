package Introduktion;

import java.awt.*;

public class Cirkelpanel_ extends javax.swing.JPanel {
    Cirkel[] cirklar = new Cirkel[40];
    @Override
    public void paintComponent(Graphics grafik) {
        super.paintComponent(grafik);

        for (Cirkel cirkel : cirklar) {
            if (cirkel!= null) {
                grafik.setColor(cirkel.färg);
                grafik.fillOval(cirkel.position.x, cirkel.position.y, 100, 100);
            }
        }
    }

}
