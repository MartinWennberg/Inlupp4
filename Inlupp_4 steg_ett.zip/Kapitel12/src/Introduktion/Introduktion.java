
package Introduktion;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Introduktion {
    private JPanel mainPanel;
    Cirkelpanel_ cirkelpanel;
    Timer timer;

    private void createUIComponents() {
        mainPanel = new Cirkelpanel_();
        cirkelpanel = (Cirkelpanel_)mainPanel;

        for (int i = 0; i <20; i++) {
        cirkelpanel.cirklar[i] = new Cirkel(new Point(i*19, i*19));
        cirkelpanel.cirklar[i+20] = new Cirkel(new Point(400 -i*19, i*19));
        }
        flyttaCirklar();
    }

    private void flyttaCirklar() {
        timer = new Timer(5, e -> {
            Random random = new Random(20);
            for (Cirkel cirkel: cirkelpanel.cirklar) {
                cirkel.flytta(random.nextInt(5)-2);

            }
            cirkelpanel.repaint();
        });
        timer.start();
    }


    public static void main(String[] args) {
        //Skapa ditt fönster
        String namn = "Introduktion";
        JFrame frame = new JFrame(namn);
        //Tala om att du vill kunna stänga ditt förnster med krysset i högra hörnet
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Ange storleken på ditt fönster och att det ska vara fast
        frame.setSize(500, 500);
        frame.setResizable(false);
        //Positionera ditt fönster i mitten av skärmen
        frame.setLocationRelativeTo(null);

        //Skapa en instans av din den här klassen som hanterar din panel
        Introduktion myForm = new Introduktion();
        //Lägg in din panel i programfönstret
        frame.setContentPane(myForm.mainPanel);
        //Visa programfönstret på skärmen
        frame.setVisible(true);
    }
}
