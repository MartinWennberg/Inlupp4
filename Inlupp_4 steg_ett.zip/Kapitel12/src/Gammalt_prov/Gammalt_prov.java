package Gammalt_prov;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Gammalt_prov {
    private JPanel mainPanel;
    private JButton approximeraPIButton;
    private pi_approximeraren_ pi_approximeraren;

    public Gammalt_prov() {
        approximeraPIButton.addActionListener(e -> {
            double pi = pi_approximeraren.approximera_pi();
            String svar = "Pi är " + pi;
            JOptionPane.showMessageDialog(mainPanel, svar, "Pi approximation",
                    JOptionPane.INFORMATION_MESSAGE);
        });
    }

    private void createUIComponents() {
        mainPanel = new pi_approximeraren_();
        pi_approximeraren = (pi_approximeraren_) mainPanel;
    }

    public static void main(String[] args) {
        //Skapa ditt fönster
        String namn = "Pi approximeraren";
        JFrame frame = new JFrame(namn);
        //Tala om att du vill kunna stänga ditt förnster med krysset i högra hörnet
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Ange storleken på ditt fönster och att det ska vara fast
        frame.setSize(500, 500);
        frame.setResizable(false);
        //Positionera ditt fönster i mitten av skärmen
        frame.setLocationRelativeTo(null);

        //Skapa en instans av din den här klassen som hanterar din panel
        Gammalt_prov myForm = new Gammalt_prov();
        //Lägg in din panel i programfönstret
        frame.setContentPane(myForm.mainPanel);
        //Visa programfönstret på skärmen
        frame.setVisible(true);
    }
}
