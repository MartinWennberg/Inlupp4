package Gammalt_prov;

public class pi_approximeraren_ extends javax.swing.JPanel {

    double approximera_pi() {
        double pi = 1;
        double nämnare = 3;

        while ((int)(4*1000000*pi) != (3141592)) {
            pi -= (1 / nämnare);
            nämnare += 2;
            pi += (1 / nämnare);
            nämnare += 2;

        }

        pi = pi * 4;
        double övriga_decimaler = pi-3.141592;
        pi -= övriga_decimaler;
        /*double övriga_decimaler = Math.PI - 3.141592;
        pi -= övriga_decimaler;*/


        return pi;
    }
}




