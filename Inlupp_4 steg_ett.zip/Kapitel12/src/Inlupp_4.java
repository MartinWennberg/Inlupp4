public class Inlupp_4 {
    int massa_lilla_block;
    int massa_stora_block;
    double hastighet_lilla_block;
    double hastighet_stora_block;
    int antalet_krockar;

    //Initiera undersökning
    //Måla upp två fyrkanter
    //Måla upp en vägg
    //Timer startar större blockets rörelse med förutbestämd hastighet
    //Om koordinater för block eller fyrkanter sammanfaller, dvs kollision så ska en kollisionsmetod anropas
    //Kollisionsmetoden använder bestämda värden på block och hastighet för beräkna ny hastighet (fart och riktning)
    //Varje gång kollisionsmetoden anropas så blir antalet_krockar inten större med en
    //Timer fortsätter att driva på händelseförlopp
    //När koordinat för stora blocket når ett visst värde, alltså när den når högerkanten och är påväg bort från vägen så avslutas programmet.

}