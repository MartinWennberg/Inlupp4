/*
 * Hjälpt av: Oscar
 * Fick hjälp med: Hur händelseindex styr programmet
 * Fick hjälp genom att han förklarade att händelseindexet aktiverar olika val och som i sig aktiverar ett nytt index
 * Lösningen bestod av att han berättade vad de olika satserna gjorde
 */








import SUD.Helper_ED;


import java.util.NoSuchElementException;
import java.util.Scanner;
/**
 * Ett program som fungerar som en SUD, ett sorts spel. Spelet har en story och man kan göra olika val.
 * Denna klass innehåller main metoden och delegerar ut uppgifter till andra metoder i andra klasser, som returnerar tillbaka
 * efterfrågade värden och strängar som behövs för spelets funktion
 */
public class SUD_MARTIN_WENNBERG_ED {
    private static final int FÖRSLUST = 1;
    private static final int VÄLJ_ALTERNATIV = 2;

    public static void main(String[] args) {
        int händelseIndex = 0; //Visa första händelsen i spelet
        char vald_tangent = 's'; //'s' startar automatiskt ett nytt spel
        while (vald_tangent != '!') {
            try {
                //Kolla vilka val som kunde göras
                String[] navigeringsAlternativ = Helper_ED.hämtaAlternativSomTangent(händelseIndex);
                // Leta upp index för valt alternativ
                int index_valt_alternativ;


                try { index_valt_alternativ = Helper_ED.hittaIndexFörValtAlternativ(vald_tangent, navigeringsAlternativ);
                    int[] tillgängliga_händelseIndex = Helper_ED.hämtaMöjligaIndex(händelseIndex);
                    händelseIndex = tillgängliga_händelseIndex[index_valt_alternativ];
                    System.out.println(Helper_ED.visaHändelsetext(händelseIndex));
                } catch (ArrayIndexOutOfBoundsException tangenttryck) {
                    if (händelseIndex== 1 || händelseIndex == 3 || händelseIndex == 6 || händelseIndex == 7){
                    System.out.println("Error! Du tryckte på en felaktig tangent, använd endast \"h\" för höger" );
                    System.out.println(" \"v\" för vänster och \"!\" för avslut ");  }
                    else {
                        System.out.println("Error! Du tryckte på en felaktig tangent, använd endast \"a\" för anfall");
                        System.out.println("\"f\" för att fly, \"s\" för att stå still och \"!\" för avslut");
                    }




                }

                //Skriv ut händelsetexten

                //Skriv ut händelsetext och inhämta nytt val
                vald_tangent = hantera_spelomgång(händelseIndex);
            } catch (NoSuchElementException spelavslut) {
                vald_tangent = '!';
            }
        }
        System.out.println("\nTack för att du spelar mitt spel!");
    }

    /**
     * En metod som hanterar en spelomgång, avgör vilka val som ska presenteras och beräknar utgång vid eventuell konflikt med monster
     * @param händelseIndex används alltså för att programmet ska veta vilka alternativ som ska presenteras
     * @return metoden returnerar ett val som användar gjort utifrån de val som presenterats utfrån händelse index
     */
    private static char hantera_spelomgång(int händelseIndex) {
        //Plocka ut valmöjligheter
        String[] händelseAlternativ = Helper_ED.hämtaAlternativSomText(händelseIndex);
        //Kontrollera om spelaren fortfarande lever
        int omgångsresultat = händelseAlternativ == null ? FÖRSLUST : VÄLJ_ALTERNATIV;
        if (omgångsresultat == FÖRSLUST) { //spelaren dör
            System.out.println("Ditt liv och ditt äventyr slutar här!");
            return '!';
        } else {
            //Ny runda, Skriv ut alla valmöjligheter
            for (String alternativ : händelseAlternativ) {
                System.out.println(alternativ);
            }
            //Låt användaren välja ett alternativ
            Scanner input = new Scanner(System.in);
            return input.next().charAt(0);
        }
    }
}