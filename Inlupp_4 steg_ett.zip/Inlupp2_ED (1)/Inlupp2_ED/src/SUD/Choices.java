package SUD;

/**
 * Klassen innehåller en struktur för spelets alternativ.
 * Om du vill kan du lägga till dina egna alternativ,
 * men var EXTREMT noga med formatet.
 * @author andlyt1ros
 */
class Choices {
    /**
     * Här finns alla texter som beskriver möjliga val för en händelse i spelet.
     * <br><br>valmöjligheter anges på formatet: "val 1;Val 2;...;x,y,..."
     * <ul>
     *     <li>Där <b>val 1-n</b> är en beskrivning av alternativet<br>
     *     <li><b>x</b> är en den tangent som spelaren ska ange för att välja valalternativ 1
     *     <li><b>y</b> är en den tangent som spelaren ska ange för att välja valalternativ 2
     *     <li><b>...</b> visar att ett godtyckligt antal valalternativ kan läggas till för en händelse
     * </ul>
     * Valmöjligheten på index 0 är ett specialfall för strider i spelet. Här måste det sista alternativet
     * vara "VINST" och sakna en tangent)
     *
     *<br>
     *    Om du vill lägga till egna val så ska dessa läggas till i <b>slutet</b> av fältet
     */
    final static String[] statements = {
            "Anfall!! (a);VINST;a", //Endast för att lösa strid (Nivå CB)
            "Starta Spelet (s);s", //Endast för att starta spelet
            "Välj höger (h);Välj vänster (v);h,v",
            "Anfall!! (a);Fly (f);Stå still (s);a,f,s"
    };
}
