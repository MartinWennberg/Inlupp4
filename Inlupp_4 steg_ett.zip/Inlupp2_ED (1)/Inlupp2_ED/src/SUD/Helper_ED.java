package SUD;

import java.util.Arrays;

/**
 * Klassen hjälper huvudprogrammet att hämta ut delar ur
 * strukturen för händelser (Story_ED) och alternativ (Choices).
 * <br><br>
 * För inlupp_2 finns ingen anledning att läsa eller ändra kod i den här klassen.
 * Använd hjälpen ctrl+Q
 *
 * @author andlyt1ros
 */
public class Helper_ED {
    private static final int STORY = 0;
    private static final int CHOICE = 1;

    /**
     * Hämtar möjliga val för en händelse i Story.statements.<br>
     * Om inga möjliga val finns returneras null.
     *
     * @param händelseIndex int motsvarande en händelse från Story.statements
     * @return String[] innehållandes texter för möjliga val för angiven händelse, eller null
     */
    public static String[] hämtaAlternativSomText(int händelseIndex) {
        String statement = Story_ED.statements[händelseIndex];
        try {
            String[] choiceNumbers = statement.substring(statement.indexOf("-->") + 3).split(",");
            String[] valalternativ = Choices.statements[Integer.parseInt(choiceNumbers[0])].split(";");
            return Arrays.copyOfRange(valalternativ, 0, valalternativ.length - 1);
        } catch (IndexOutOfBoundsException slutPåÄventyret) {
            return null;
        } catch (NumberFormatException formatFel) {
            assert false : (meddelandeOmSyntaxFel(statement));
            return null;
        }
    }

    /**
     * Hämtar möjliga val för en händelse i Story.statements.
     * Om inga möjliga val finns returneras null.
     *
     * @param händelseIndex int motsvarande en händelse från Story.statements
     * @return String[] innehållandes tangenter för möjliga val för angiven händelse
     */
    public static String[] hämtaAlternativSomTangent(int händelseIndex) {
        String statement = Story_ED.statements[händelseIndex];
        String[] choiceNumbers = statement.substring(statement.indexOf("-->") + 3).split(",");
        try {
            String[] options = Choices.statements[Integer.parseInt(choiceNumbers[0])].split(";");
            assert choiceNumbers.length == 1 || choiceNumbers.length - 1 < options.length : meddelandeOmSyntaxFel(CHOICE, Choices.statements[Integer.parseInt(choiceNumbers[0])]);
            return options[choiceNumbers.length - 1].split(",");
        } catch (IndexOutOfBoundsException slutPåÄventyret) {
            assert false : Helper_ED.meddelandeOmSyntaxFel(statement);
            return null;
        }
    }

    /**
     * Metod för att plocka ut beskrivande text för en händelse i Story.statements
     *
     * @param händelseIndex int motsvarande en händelse från Story.statements
     * @return String motsvarande den beskrivande texten för vald händelse
     */
    public static String visaHändelsetext(int händelseIndex) {
        String statement = Story_ED.statements[händelseIndex];
        try {
            return statement.substring(0, statement.indexOf("-->"));
        } catch (StringIndexOutOfBoundsException formatFel) {
            assert false : (meddelandeOmSyntaxFel(statement));
            return "Syntax error";
        }
    }

    /**
     * Hämtar index för de händelser som följer av de möjliga val användaren har
     * utifrån angivet händelseIndex.
     *
     * @param händelseIndex int motsvarande en händelse från Story.statements
     * @return int[] innehållandes möjliga nästkommande index för händelsen i Story.statements
     */
    public static int[] hämtaMöjligaIndex(int händelseIndex) {
        String statement = Story_ED.statements[händelseIndex];
        int[] händelseKonsekvenser = omvandlaTillInts(statement.substring(statement.indexOf("-->") + 3).split(","));
        if (händelseKonsekvenser[0] != -1)
            händelseKonsekvenser = Arrays.copyOfRange(händelseKonsekvenser, 1, händelseKonsekvenser.length);
        return händelseKonsekvenser;
    }

    /**
     * Hjälpmetod för att konvertera händelseindex från String till int.
     * Detta är nödvändigt då index är angivna som en del av en text.
     *
     * @param konsekvenser int[], fält med möjliga händelseindex
     * @return int[], fält med möjliga händelseindex
     */
    private static int[] omvandlaTillInts(String[] konsekvenser) {
        int[] händelseKonsekvenser = new int[konsekvenser.length];
        for (int i = 0; i < konsekvenser.length; i++) {
            try {
                händelseKonsekvenser[i] = Integer.parseInt(konsekvenser[i]);
            } catch (NumberFormatException e) {
                System.out.println("ERROR - Felaktigt format i konsekvenslistan");
                System.out.println(Arrays.toString(konsekvenser));
                return händelseKonsekvenser;
            }
        }
        return händelseKonsekvenser;
    }

    /**
     * Hjälpmetod för debugging. Används av assert för att visa var syntaxfelet finns i story
     *
     * @param statement String motsavrande det statement som orsakade felet
     * @return String för beskrivande felmeddelande avsett för programmeraren.
     */
    private static String meddelandeOmSyntaxFel(String statement) {
        return meddelandeOmSyntaxFel(STORY, statement);
    }

    /**
     * Hjälpmetod för debugging. Används av assert för att visa var syntaxfelet finns i story eller choices
     *
     * @param mode      int 0 för STORY, 1 för CHOICE visar i vilken struktur felet finns.
     * @param statement String motsavrande det statement som orsakade felet
     * @return String för beskrivande felmeddelande avsett för programmeraren.
     */
    private static String meddelandeOmSyntaxFel(int mode, String statement) {
        String meddelande = "\n***********************************\n";
        meddelande += mode == STORY ? "\tFelaktig syntax i Story.statements!! " : "\tFelaktig syntax i Choice.statements!! " +
                "\n\t\t" + statement +
                "\n\tSpelet kan inte fortsätta.";
        meddelande += "\n***********************************";
        return meddelande;
    }

    /**
     * Letar upp index för vald tangent i listan med navigeringsalternativ.
     * Om vald tangent saknas i listan med navigeringsalternativ returneras ett negativt värde.
     *
     * @param vald_tangent          char, av användaren vald tangent
     * @param navigeringsAlternativ String[], alternativ som spelaren kunde välja bland
     * @return int, index för vald tangent i listan med navigeringsalternativ, annars ett negativt värde
     */
    public static int hittaIndexFörValtAlternativ(char vald_tangent, String[] navigeringsAlternativ) {
        if (navigeringsAlternativ == null)
            return -1;
        else
            return String.join("", navigeringsAlternativ).indexOf(vald_tangent);
    }
}
