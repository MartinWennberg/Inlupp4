package SUD;
/**
 * Klassen innehåller en struktur för spelets händelser.
 * Om du vill kan du lägga till dina egna händelser,
 * men var EXTREMT noga med formatet.
 * @author andlyt1ros
 */
class Story_ED {
    /**
     * Här finns alla texter som beskriver aktell händelse i spelet.
     * <br><br>Händelsetexten anges på formatet: "text -->i,x, y, ..."
     * <ul>
     *     <li>Där <b>text</b> är en beskrivning av händelsen<br>
     *     <li><b>i</b> är index i fältet SUD.Choices.statements där möjliga valalternativ finns angivna<br>
     *         om i == -1 finns inga valalternativ och spelet är slut.
     *     <li><b>x</b> är nästa händelse i spelet om valalternativ 1 väljs av spelaren
     *     <li><b>y</b> är nästa händelse i spelet om valalternativ 2 väljs av spelaren
     *     <li><b>...</b> visar att ett godtyckligt antal valalternativ kan läggas till för en händelse
     * </ul>
     * <br>
     *     Om du vill lägga till egna händelser så ska dessa läggas till i <b>slutet</b> av fältet
     */
    final static String[] statements = {
            "\n\n\nInlupp_2 startas nu om! -->1,1",
            "Du är hjälten i den här historien! \nDina val kommer att " +
                    "styra ditt öde! \nDu kan när som helst avsluta spelet genom att" +
                    " trycka på '!' eller ctrl+d\n\nDu står mitt i ett rum och kan " +
                    "gå ut genom en dörr till höger eller vänster -->2,2,3",
            //2
            "Du gick till höger.\nGå aldrig åt höger! -->-1",
            //3
            "Du gick till vänster.\nBra val! -->2,2,4",
            //4
            "Du möter ett monster! -->3,5,6,7",
            //5
            "Anfall aldrig ett monster, de är för elaka! -->-1",
            //6
            "Bättre fly än illa fäkta. Du kan fly till höger eller vänster! -->2,2,3",
            //7
            "Smart! Monster är inte så smarta. Monstret vandrar iväg. \nVill du gå till höger" +
                    " eller till vänster -->2,2,3",
            //8
            "Monstret dör, du har segrat! Du kan nu fortsätta din färd till höger eller vänster. -->2,2,3",  //För CB
            //9
            "Du strider med monstret! -->0,9,8" //För CB
    };
}
